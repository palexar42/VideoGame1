/*EASTER EGG CREDIT SCREEN
		WORKING BLOCK OF EASTER EGG CODE --------------------------------
		numRoids = 1;
		
		
		while(roids.length<numRoids)
		{
			var proto = protos[roidNumber];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = right;
			roid.position.y = 0;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
			if(roids.length==1) roidNumber++;
			if(roidNumber>10)
			{
				roidNumber = 9;
			}
		}--------------------------------------------------------------------
		*/


// global constants

var UP_ARROW = 38;
var LEFT_ARROW = 37;
var RIGHT_ARROW = 39;
var A_KEY = 65;
var S_KEY = 83;
var D_KEY = 68;
var F_KEY = 70;
var SPACE_BAR = 32;

var SCORE = 0;
// PLAY STATE
var PLAYING = 0;
var KILLED = 1;
var GAME_OVER = 2;
var GAME_STATE = PLAYING;
var ENDGAME = false;
var POINTS = 0; //-------------------------------------------------------------------------------------------------------
var TITLE_SCREEN = true;
var DRAW = true;
var DRAWDARK = true;
var COUNTER = 0;

var EasterBossAnimation1 = false;
var EasterBossAnimation2 = false;
var EasterBossAnimation2Draw = true;
var EasterRound1 = false;
var EasterBossAnimation3 = false;
var EasterRound2 = false;
var preRound = true;
var EasterBossAnimation4 = false;
var EasterBossAnimation4Draw = true;
var TurnDark = false;
var FinalBattle = false;


var KILL_TIMER = 0;
var KILL_WAIT = 4;
var KILL_REPULSION = 250;
var KILL_WAIT_DECELERATION = 0.99;
var NUM_LIVES = 4;
var EasterGhostSpeed = -100;



// CONSTANTS RELATED TO THE SHIP
var SHIP_TURN_RATE = 5.0;
var SHIP_ACCEL_RATE = 600.0;
var SHIP_DECEL_RATE = 0.4;

// CONSTANTS RELATED TO SHOTS
var MAX_SHOTS = 4;
var SHOT_SPEED = 1000.0;
var SHOT_LIFE = 20.0;

// CONSTANTS RELATED TO PARTICLES
var PARTICLE_SPEED = 400.0;
var PARTICLE_BOUNCE = 500.0;
var NUM_PARTICLES = 500; 
var PARTICLES_PER_EXPLOSION = 75; 
var PARTICLES_SHIP_EXPLOSION = 250;

//Game mechanics/booleans
var shipDamage = 1;

var FIRST = true;
var BOSSHP = 40;
var BOSSSPAWN = false;
var SWITCH = true;
var currHP = 0;
var NEGFIVESW = true;
var NEGSIXSW = true;
var NEGSEVSW = true;
var NEGEIGSW = true;
var NEGNINESW = true;
var NEGTEN = true;
var EBOSSSPAWN = true;
var BOSSSPAWN2 = true;
var EasterSW = false;
var EasterSWDe = false;
var EasterSW3 = false;
var FirstRemove = true;
var COUNTER2 = 0;
var finalFly = false;
var cantMove = false;

// CONSTANTS RELATED TO ASTEROIDS
var ROIDS_AT_LEVEL0 = 5;
var MAX_STARTING_ROIDS = 20;
var ROID_SPEED = 100;
var ROID_ROTATION = 2;
var ROID_BOUNCE = 200;
var ROIDS_PER_SPLIT = 2;

var cherry = 3;
var strawberry = 3;
var orange = 3;
var apple =3 ;
var melon =3;
var galaxy = 2;
var bell = 2;
var key = 1;

var asteroidsLeft = 0;

var invun = false;
var invunTimer = 2000;
var ResetTimer = 2000;


var resetBossGhosts = true;


// Musics and Sound
var MAIN_AUDIO = new Audio('Theme.mp3');
MAIN_AUDIO.loop = true;

var BOSS_AUDIO = new Audio('GAMEON.mp3');
BOSS_AUDIO.loop = true;

var BOSS_DOWN_AUDIO = new Audio('PACMAN.mp3');

var TITLE_AUDIO = new Audio('TitleTheme.mp3');
TITLE_AUDIO.loop = true;

var DARK_THEME = new Audio('darkTheme.mp3');
DARK_THEME.loop = true;

var DARK_BOSS = new Audio('darkBoss.mp3');
DARK_BOSS.loop = true;

var START = true;

//Credit Screen Vars
var roidNumber = 10;

// LEVEL TIMER
var LEVEL_WAIT = 3.0;
var LEVEL_TIMER = LEVEL_WAIT;
var CURR_LEVEL = 1;

//var NAMEOFROID = "test"

var StringTitle = "PacSpace";
var NegStringTitle = "NegativePacSpace";
// READOUT
var READOUT = document.createElement( 'div' );
READOUT.innerHTML = getReadout();
READOUT.style["position"] = "absolute";
READOUT.style["width"] = "100%";
READOUT.style["text-align"] = "center";
READOUT.style["bottom"] = "0px";
READOUT.style["color"] = "#ff0"
document.body.insertBefore(READOUT, document.body.firstChild);

function getReadout()
{
	var s = "<pre>" + StringTitle + " " +
		    "     Level:" + CURR_LEVEL +
		    
		    "     Points:" + POINTS + "   Target HP =  " + currHP; 
	if (NUM_LIVES <= 0) 
	        s += "     (GAME OVER)</pre>";
	else
	        s += "     Lives:" + NUM_LIVES + "</pre>";
	return s;
}

var LEVEL_2 = 900;
var LEVEL_3 = 2700;
var LEVEL_4 = 3900;
var LEVEL_5 = 7900;
var LEVEL_6 = 48000;
var LEVEL_7 = 83000;
var LEVEL_8 = 128000;
var LEVEL_9 = 264500; 
var LEVEL_10 = 464500;

function asteroidsMain(sceneNode)
{
	LEVEL_TIMER -= frameDuration;
	var ship = sceneNode.getObjectByName("ship");
	var left   = sceneNode.getObjectByName("left").position.x;
	var right  = sceneNode.getObjectByName("right").position.x;
    var top = 450;
    var bottom = -450;
	var shots  = sceneNode.getObjectByName("shots");
    var asteroidShots = sceneNode.getObjectByName("AsteroidShots");
	var particles = sceneNode.getObjectByName("particles");
	
	var asteroidPrototypes = sceneNode.getObjectByName("asteroidPrototypes");
	var asteroids = sceneNode.getObjectByName("asteroids");
	
	var bannerPrototypes = sceneNode.getObjectByName("bannerPrototypes");
	var banners = sceneNode.getObjectByName("banners");
	
	if(ENDGAME)
	{
		CURR_LEVEL = 11;
	}
	else if (POINTS > LEVEL_10) {
		CURR_LEVEL = 10;
	}
	else if (POINTS > LEVEL_9) CURR_LEVEL = 9;
	else if(POINTS > LEVEL_8) CURR_LEVEL = 8;
	else if(POINTS > LEVEL_7) CURR_LEVEL = 7;
	else if(POINTS > LEVEL_6) CURR_LEVEL = 6;
	else if(POINTS > LEVEL_5) CURR_LEVEL = 5;
	else if(POINTS > LEVEL_4) CURR_LEVEL = 4;
	else if(POINTS > LEVEL_3) CURR_LEVEL = 3;
	else if(POINTS > LEVEL_2) CURR_LEVEL = 2;
	else if(POINTS < -5800) 
	{
		CURR_LEVEL = -10;
		DARK_THEME.pause();
		DARK_BOSS.play();
	}
	else if(POINTS < -1450) CURR_LEVEL = -9;
	else if(POINTS < -900) CURR_LEVEL = -8;
	else if(POINTS < -650) CURR_LEVEL = -7;
	else if(POINTS < -550) CURR_LEVEL = -6;
	else if(POINTS < -500) CURR_LEVEL = -5;
	else if(POINTS < -250) CURR_LEVEL = -4;
	else if(POINTS < -30) CURR_LEVEL = -3;
	else if(POINTS<-2) 
	{
		CURR_LEVEL = -2;
		StringTitle = NegStringTitle
	}
	else if(POINTS == -2)
	{
		CURR_LEVEL = -1;
		if(SWITCH)
		{
			removeAllRoids(asteroids);
			removeAllBanners(banners);
			SWITCH = false;
			NUM_LIVES = 8;
		}
	}
	else if(!TITLE_SCREEN)
	{
		CURR_LEVEL = 1;
		TITLE_AUDIO.pause();
		MAIN_AUDIO.play();
		SWITCH = true;
	}// -------------------------- CREATE DIFFERENT ASTEROID SPAWNER AND DIFFERENT POINTS
	else
	{
		//title screen also choose difficulty (Maybe add easter eggs here later
		CURR_LEVEL = 0;
		TITLE_AUDIO.play();
		if(POINTS==1)
		{
			//easy mode
			TITLE_SCREEN= false;
			removeAllRoids(asteroids);
			removeAllBanners(banners);
			NUM_LIVES = 10;
			READOUT.innerHTML = getReadout();
		}
		else if(POINTS==2)
		{
			//normal mode
			TITLE_SCREEN= false;
			removeAllRoids(asteroids);
			removeAllBanners(banners);
		}
		else if(POINTS==3)
		{
			//Hard mode
			TITLE_SCREEN= false;
			removeAllRoids(asteroids);
			removeAllBanners(banners);
			NUM_LIVES = 1;
			READOUT.innerHTML = getReadout();
		}
	}
	
	
	
	// need to create asteroid paths here
	if (GAME_STATE == PLAYING && NUM_LIVES > 0) {
		
		//createAsteroidsForLevel(CURR_LEVEL, asteroidPrototypes, asteroids, left, right, top, bottom);
		createAsteroidsForLevel(CURR_LEVEL, asteroidPrototypes, asteroids, left, right, bottom, top, bannerPrototypes, banners);
		updateShip(asteroids, particles, ship, left, right);
		asteroidsLeft = asteroids.children.length;
	}
	/*else if(ENDGAME)
	{
		ship.position.x = 0;
		ship.position.y = -300;
	}*/
																					//top boundary
	updateShots(ship, asteroids, particles, asteroidPrototypes, shots, left, right, 410);
	updateParticles(ship, asteroids, shots, particles, left, right, top, -450);
	updateAsteroids(asteroids, left, right, ship, asteroidShots, asteroidPrototypes);
	
	READOUT.innerHTML = getReadout();
}

function removeAllRoids(asteroids)
{
	numRoids = 0;
	var roids = asteroids.children;
		while(roids.length>numRoids)
		{
			roids.pop();
		}
}

function removeAllBanners(banners)
{
	numBan = 0;
	var bans = banners.children;
		while(bans.length>numBan)
		{
			bans.pop();
		}
}

function toroidalBoundary(position, left, right)
{
	if (position.x > right-5)  position.x = left+5;
    if (position.x < left+5)   position.x = right-5;
}

function collision(ship, asteroid)
{
	var shipPos = ship.position;
	var asteroidPos = asteroid.position;
	
	var rectShip = {x: shipPos.x-64, y: shipPos.y-64, width: 64, height: 64};
	var rectAsteroid = {x: asteroidPos.x-32, y: asteroidPos.y-32, width: 32, height: 32};
	
	// using axis aligned bounding box
	if( rectShip.x < rectAsteroid.x + rectAsteroid.width && rectShip.x + rectShip.width > rectAsteroid.x && rectShip.y < rectAsteroid.y + rectAsteroid.height && rectShip.y + rectShip.height > rectAsteroid.y)
	{
		return true;
	}
	
	return false;
	
	
	
	/*// trying with lines
	var line1startX = shipPos.position.x-64;
	var line1startY = shipPos.position.y-64;
	var linesendX = shipPos.position.x;
	var linesendY = shipPos.position.y+64;
	
	var line1Distance = Math.sqrt((line1startX-linesendX
	
	var line2startX = shipPos.position.x+64;
	var line2startY = shipPos.position.y-64;
	
	var lineAstStartX = asteroidPos.x-32;
	var lineAstStartY = asteroidPos.y-32;
	var lineAstEndX = asteroidPos.x+32;
	var lineAstEndY = asteroidPos.y-32;
	
*/
	
	/*
	var shipTriangleHitBoxLeftX = shipPos.x-64;
	var shipTriangleHitBoxLeftY = shipPos.y-64;
	var shipTriangleHitBoxRightX = shipPos.x+64;
	var shipTriangleHitBoxRightY = shipPos.y+64;
	var shipTriangleHitBoxTopX = shipPos.x;
	var shipTriangleHitBoxTopY = shipPos.y+64;
	
	// change the - 32 to a lookup table based on asteroids name.
	var asteroidBottomLeftX = asteroidPos.x-32;
	var asteroidBottomLeftY = asteroidPos.y-32;
	var asteroidBottomX = asteroidPos.x;
	var asteroidBottomY = asteroidPos.y - 32;
	var asteroidBottomRightX = asteroidPos.x+32;
	var asteroidBottomRightY = asteroidPos.y-32;
	
	if(asteroidBottomLeftX < shipTriangleHitBoxRightX && asteroidBottomLeftY < shipTriangleHitBoxRightY
	
	//var d2 = (pa.x-pb.x)*(pa.x-pb.x) + (pa.y-pb.y)*(pa.y-pb.y);
	//if (d2 < (a.scale.x+b.scale.x)*(a.scale.x+b.scale.x)*0.25*scale) return true;
	return false;*/
}

function updateShip(asteroidNode, particleNode, ship, left, right)
{
    var material = ship.material;
    var texture = material.map;

    // Update the ship position
	if((pressedKeys[LEFT_ARROW] || pressedKeys[A_KEY]) && !ENDGAME && !EasterBossAnimation1 && !EasterBossAnimation2 && !EasterBossAnimation3 && !EasterRound2 && !finalFly &&!cantMove)
	{
		ship.position.x -= 5;
		if(invun) invun--;
		if(invunTimer<=0) invun=false
	}
	else if((pressedKeys[RIGHT_ARROW] || pressedKeys[D_KEY]) && !ENDGAME && !EasterBossAnimation1 && !EasterBossAnimation2 && !EasterBossAnimation3 && !EasterRound2 && !finalFly && !cantMove)
	{
		ship.position.x += 5;
		if(invun) invun--;
		if(invunTimer<=0) invun=false
	}
	else if(ENDGAME || EasterBossAnimation1 || EasterBossAnimation2 || EasterBossAnimation3 || finalFly || cantMove)
	{
		if(ship.position.x>0) ship.position.x -=1;
		if(ship.position.x<0) ship.position.x +=1;
		//ship.position.x = 0;
		if((ENDGAME||finalFly) && (ship.position.x<=10 && ship.position.x>=-10)) ship.position.y += 1;
	}
    toroidalBoundary(ship.position, left, right);

    // Collision of ship with asteroids
    var asteroids = asteroidNode.children;
    if (GAME_STATE == PLAYING) {
        for (var i=asteroids.length-1; i>=0; i--) {
            var asteroid = asteroids[i];
            if (collision(ship, asteroid) && !invun) {
                //explodeParticles(asteroid, particleNode, PARTICLES_PER_EXPLOSION);
               // explodeParticles(ship, particleNode, PARTICLES_SHIP_EXPLOSION);
				asteroid.position.y = -440;
                // Reset the ship
                ship.position.x = 0;
                ship.position.y = -300;
				invunTimer = ResetTimer;
                NUM_LIVES--;
                if (NUM_LIVES == 0)	
				{
					PLAY_STATE = GAME_OVER;
					ship.visible = false;
				}
				READOUT.innerHTML = getReadout();
				
				invun = true;
               // BOOM_AUDIO.load();
                //BOOM_AUDIO.play();
                //THRUST_AUDIO.pause();

                break;
            }
        }
    }
}
var EXPLOSION_PARTICLE = 0;
function explodeParticles(center, particleNode, numParticles)
{
	var particles = particleNode.children;
    var x = center.position.x;
    var y = center.position.y;
    var vx = center.userData["velocity"][0];
    var vy = center.userData["velocity"][1];

    for (var i = 0; i < numParticles; i++)
    {
    	var index = EXPLOSION_PARTICLE;
        var particle = particles[index];
        var dx = (Math.random()-0.5) * 30.0;
        var dy = (Math.random()-0.5) * 30.0;
        particle.position.x = x + dx;
        particle.position.y = y + dy;
        
        var scale = (i%2) + 1.0;
        //if (i % 2 == 0) scale = 3.0;
        var d = Math.sqrt(dx*dx + dy*dy);
        var velocity = particle.userData["velocity"];
        velocity[0] = vx + scale * 120.0 * (dx / d);
        velocity[1] = vy + scale * 120.0 * (dy / d);

        EXPLOSION_PARTICLE++;
        if (EXPLOSION_PARTICLE >= particles.length) {
        	EXPLOSION_PARTICLE = 50;
        }
    }
}

var CURR_SHOT = 0;
function updateShots(ship, asteroidNode, particleNode, prototypeNode,
	shotsNode, left, right, top)
{
	var shots = shotsNode.children;

	// Make the initial shots
	while (shots.length < MAX_SHOTS) {
		shots[0].visible = false;
		var shot = shots[0].clone();
		shot.userData["velocity"][1] = 10;
		shots.push(shot);
	}

	// Update the position of the shots
	for (var i=0; i<shots.length; i++) {
		var shot = shots[i];
		var velocity = shot.userData["velocity"];
		//shot.position.x += velocity[0] * frameDuration;
		shot.position.y += velocity[1] *(frameDuration+0.2);
		toroidalBoundary(shot.position, left, right);
		shot.userData["time"] -= frameDuration;
		if (shot.position.y > 400) shot.visible = false;
	}

	// Add shots based on keyboard
	if ((pressedKeys[SPACE_BAR] && shots[CURR_SHOT].visible == false && ship.visible == true) && !ENDGAME && !EasterBossAnimation1 && !EasterBossAnimation2 && !EasterBossAnimation3 && !cantMove && !EasterRound2) {
		shot = shots[CURR_SHOT];
		shot.visible = true;
		shot.userData["time"] = SHOT_LIFE;
		
		if(invun) invun--;
		if(invunTimer<=0) invun=false
		
		// Compute the direction the ship is facing
		var rot = ship.material.rotation;
		var rad = 0.5*ship.scale.x + 3;
		var dx  = -Math.sin(rot);
		var dy  = Math.cos(rot);
		
		// Compute the initial position of the shot
		shot.position.x = ship.position.x + dx * rad;
		shot.position.y = ship.position.y + dy * rad;
		
		// Compute the initial velocity of the shot
		shot.userData["velocity"][1] = 50;

		//SHOT_AUDIO.load();
		//SHOT_AUDIO.play();
	} 
	if (pressedKeys[SPACE_BAR]) {
		CURR_SHOT = (CURR_SHOT+1)%MAX_SHOTS;
		pressedKeys[SPACE_BAR] = false;
	}

	// Collide shots with Asteroids
	var asteroids = asteroidNode.children;
	for (var i=0; i<shots.length; i++) {
		if (shots[i].visible == false) continue;
		for (var j=asteroids.length-1; j>=0; j--) {
			if (collision(shots[i], asteroids[j], 0.9)) {
				if(asteroids[j].name=="PacMan")
					{
						//Lower pacman health by 50;
						BOSSHP-=shipDamage;
						currHP = BOSSHP;
						if(BOSSHP<=0)
						{
							//get rid of pacman, play death sound, start end animation
							//asteroids.splice(j,1);
							ENDGAME = true;
							BOSS_DOWN_AUDIO.play();
							asteroids.splice(j,1);
							var addPoints = asteroids[j].userData["Points"]
							POINTS += addPoints;
							READOUT.innerHTML = getReadout();
						}
						READOUT.innerHTML = getReadout();
						shots[i].visible = false;
						break;
					}
				else if(asteroids[j].name=="darkKey")
					{
						currHP = asteroids[j].userData["HP"];
						currHP-=shipDamage;
						if(currHP<=0)
						{
							var addPoints = asteroids[j].userData["Points"];
							POINTS += addPoints;
							READOUT.innerHTML = getReadout();
							asteroids.splice(j,1);
						}
						else asteroids[j].userData["HP"] = currHP;
						
						shots[i].visible = false;
					}
				else if(asteroids[j].name=="darkOrange")
					{
						currHP = asteroids[j].userData["HP"];
						currHP-=shipDamage;
						if(currHP<=0)
						{
							var addPoints = asteroids[j].userData["Points"];
							POINTS += addPoints;
							READOUT.innerHTML = getReadout();
							asteroids.splice(j,1);
						}
						else asteroids[j].userData["HP"] = currHP;
						
						shots[i].visible = false;
					}
				else if(asteroids[j].name=="darkOrangy")
					{
						currHP = asteroids[j].userData["HP"];
						currHP-=shipDamage;
						if(currHP<=0)
						{
							var addPoints = asteroids[j].userData["Points"];
							POINTS += addPoints;
							READOUT.innerHTML = getReadout();
							asteroids.splice(j,1);
						}
						else asteroids[j].userData["HP"] = currHP;
						
						shots[i].visible = false;
					}
				else if(asteroids[j].name=="red"||asteroids[j].name=="blue"||asteroids[j].name=="orangy"||asteroids[j].name=="pink")
					{
						currHP = asteroids[j].userData["HP"];
						currHP-=shipDamage;
						if(currHP<=0)
						{
							var addPoints = asteroids[j].userData["Points"];
							POINTS += addPoints;
							READOUT.innerHTML = getReadout();
							asteroids.splice(j,1);
						}
						else asteroids[j].userData["HP"] = currHP;
						
						shots[i].visible = false;
					}
					else if(asteroids[j].name=="DarkPacManBoss")
					{
						currHP = asteroids[j].userData["HP"];
						currHP-=shipDamage;
						/*if(currHP<=0&&EasterRound1)
						{
							//EasterBossAnimation1 = true;
							EasterSW = true;
						}*/
						if(currHP<=0 && FinalBattle)
						{
							finalFly = true;
							FinalBattle = false;
							BOSS_DOWN_AUDIO.play();
						}
						else if(currHP<=0)
						{
							//ENDGAME = true;
							//BOSS_DOWN_AUDIO.play();
							//removeAllRoids(asteroids);
							EasterBossAnimation3 = true;
							EasterRound1 = false;
							EasterSW3 = true;
							//BOSSSPAWN2 = true;
						}
						else asteroids[j].userData["HP"] = currHP;
						
						shots[i].visible = false;
					}
				else {
					var addPoints = asteroids[j].userData["Points"];
					POINTS += addPoints;
					READOUT.innerHTML = getReadout();
					//explodeParticles(asteroids[j], particleNode, PARTICLES_PER_EXPLOSION);
					asteroids.splice(j,1);
					shots[i].visible = false;
					//if (asteroids.length == 0) {
					//	CURR_LEVEL++;
					//	LEVEL_TIMER = LEVEL_WAIT;
					//}
					//BOOM_AUDIO.load();
					//BOOM_AUDIO.play();
					break;
				}
			}
		}
	}
}

function updateParticles(ship, asteroidNode, shotNode, particleNode, left, right, top, bottom)
{
	var particles = particleNode.children;
	while (particles.length < NUM_PARTICLES) {
		var particle = particles[0].clone();
		particles.push(particle);
		particle.userData["velocity"][1] = (Math.random() - 0.5) * PARTICLE_SPEED;
		particle.userData["desVelocity"][1] = particle.userData["velocity"][1];
		particle.position.x = left   + (Math.random() * (right-left));
		particle.position.y = 450;
    }

	for (var i=0; i<particles.length; i++) {
		var particle = particles[i];
		var velocity = particle.userData["velocity"];

		particle.position.x += velocity[0] * frameDuration;
		particle.position.y += velocity[1] * frameDuration;

		velocity[0] *= -(1.0 - (frameDuration * 0.5)); // try to make the pixel shake
		velocity[1] *= (1.0 - (frameDuration * 0.5));
        velocity[1] += (frameDuration * 0.5) * particle.userData["desVelocity"][1];

		toroidalBoundary(particle.position, left, right);
		if(particle.position.y<=-460) particle.position.y = 450;
	}
}

function createAsteroidsForLevel(level, prototypes, asteroids, left, right, bottom, top, bannerPrototypes, banners)
{
	var roids = asteroids.children;
	var protos = prototypes.children;
	
	var banProtos = bannerPrototypes.children;
	var bans = banners.children;
	
	var numRoids =3 ;
   // debug(protos.length);
    
    

	//debug(roids.length);
	/*if(roids.length<=numRoids)
	{
		while(roids.length<numRoids)
		{
            numRoids = 3;
			var proto = protos[0];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 450;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}*/
	
	//28,29,30,31 are red, blue ,pink, orange
	//32, 33, 34, 35 are dark variants in same order.
	if(CURR_LEVEL==-10)
	{
		//boss level with evil pacman
		if(NEGTEN) removeAllRoids(asteroids);
		NEGTEN = false;
		if(EBOSSSPAWN)
		{
			var proto = protos[36];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left + 20;
			roid.position.y = 300;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = -EasterGhostSpeed;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			EBOSSSPAWN = false;
			EasterBossAnimation1 = true;
		}
		if(EasterBossAnimation2 && EasterBossAnimation2Draw)
		{
			var proto = protos[28];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left + 20;
			roid.position.y = 250;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = -EasterGhostSpeed;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			var proto = protos[29];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = right - 20;
			roid.position.y = 200;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = EasterGhostSpeed;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			var proto = protos[30];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left + 20;
			roid.position.y = 150;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = -EasterGhostSpeed;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			var proto = protos[31];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = right - 20;
			roid.position.y = 100;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = EasterGhostSpeed;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			EasterBossAnimation2Draw = false;
		}
		//actual round 1 starts
		if(EasterRound1)
		{
			EasterBossAnimation1 = false;
			EasterBossAnimation2 = false;
			numRoids=15
			if(resetBossGhosts)
			{
				removeAllRoids(asteroids);
				
				var proto = protos[36];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 300;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[28];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 250;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[29];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 200;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[30];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 150;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[31];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 100;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				resetBossGhosts = false;
			}
			while(roids.length<numRoids)
			{
				var i = Math.floor(Math.random() * (26 - 20 + 1) + 20);
				//POINTS = i
				//READOUT.innerHTML = getReadout();
				var proto = protos[i];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = left+ (Math.random() * (right-left))
				if(i == 25) roid.position.y = -250;
				else roid.position.y = 450;
				roid.material = Object.create(roid.material);
			  //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			  //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
				
				roids.push(roid);
			}
		}
		
		if(EasterBossAnimation3)
		{
			if(EasterSW3)
			{
				removeAllRoids(asteroids);
				EasterSW3 = false;
			}
			if(BOSSSPAWN2)
			{
				var proto = protos[36];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = right - 20;
				roid.position.y = 300;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = EasterGhostSpeed;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				BOSSSPAWN2 = false;
				
				var proto = protos[28];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = right - 20;
				roid.position.y = 250;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = EasterGhostSpeed;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[29];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = right - 20;
				roid.position.y = 200;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = EasterGhostSpeed;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[30];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = right - 20;
				roid.position.y = 150;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = EasterGhostSpeed;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				var proto = protos[31];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = right - 20;
				roid.position.y = 100;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = EasterGhostSpeed;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
				
				
				
				EasterRound2 = true;
				
				cantMove = true;
			}
		}

		
		if(TurnDark)
		{
			/*CHERRY TESTER =========================================================
				var proto = protos[0];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 0;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = -50;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);
			*/
			/*
			for(var i=0; i<=roids.length; i++)
			{
				if(roids[i].name=="DarkPacManBoss")
				{
				}
				else if(roids[i].name=="red")
				{
					roids.splice(i,1)
					var proto = protos[32];
					proto.visible = false;
					var roid = proto.clone();
					roid.visible = true;
					roid.position.x = 0;
					roid.position.y = 250;
					roid.material = Object.create(roid.material);
					roid.userData["velocity"][0] = 0;
					roid.userData["velocity"][1] = 0;
					roids.push(roid);
				}
			}
			
			//TurnDark = false;
			EasterRound2 = false;
			FinalBattle = true;*/
			
			
		}
		
		if(FinalBattle)
		{
			cantMove = false;
			if(COUNTER2>=300)
			{
				numRoids = 15;
				if(FirstRemove)
				{
					removeAllRoids(asteroids);
					FirstRemove= false;
					var proto = protos[36];
					proto.visible = false;
					var roid = proto.clone();
					roid.visible = true;
					roid.position.x = right - 20;
					roid.position.y = 300;
					roid.material = Object.create(roid.material);
					roid.userData["velocity"][0] = -300;
					roid.userData["velocity"][1] = 0;
					roid.userData["HP"] = 5;
					roids.push(roid);
				}
				
				while(roids.length<numRoids)
				{
					var i = Math.floor(Math.random() * (4 - 0 + 1) + 0);
					//POINTS = i
					//READOUT.innerHTML = getReadout();
					if(i==0) i=32;
					else if(i==1) i=33;
					else if(i==2) i=34
					else i=35;
					var proto = protos[i];
					proto.visible = false;
					var roid = proto.clone();
					roid.visible = true;
					roid.position.x = left+ (Math.random() * (right-left))
					if(i == 35) roid.position.y = -250;
					else roid.position.y = 450;
					roid.material = Object.create(roid.material);
				  //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
				  //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
					
					roids.push(roid);
				}
			}
			else COUNTER2++;
		}
		
		if(finalFly)
		{
			removeAllRoids(asteroids);
		}
		
		/*if(EasterBossAnimation4) //&& EasterBossAnimation4Draw)
		{
			EasterBossAnimation3 = false;
			
			roids[1].userData["velocity"][0] = -50;*/
			
			//----------------CHERRY TEST===============================================================
			    /*var proto = protos[0];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = 0;
				roid.position.y = 0;
				roid.material = Object.create(roid.material);
				roid.userData["velocity"][0] = 0;
				roid.userData["velocity"][1] = 0;
				roids.push(roid);*/
			//==============================================================================================
			/*for(var i=0; i<=roids.length; i++)
			{
				if(roids[i].name=="red")
				{
					roids[i].material.map = "DarkRedBuilt.png";
				}
			}*/
			
			//EasterBossAnimation4Draw = false;
		//}
		/*
		if(EasterSWDe)
		{
			removeAllRoids(asteroids);
			var proto = protos[36];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = right - 20;
			roid.position.y = 300;
			roid.material = Object.create(roid.material);
			roid.userData["velocity"][0] = 50;
			roid.userData["velocity"][1] = 0;
			roids.push(roid);
			
			EasterSWDe = false;
		}*/
	}
	if(CURR_LEVEL==-9)
	{
		if(NEGNINESW) removeAllRoids(asteroids);
		NEGNINESW = false;
		numroids = 1;
		while(roids.length<numRoids)
		{
			var proto = protos[27];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+(right) //(Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
			roid.userData["Points"] = -5000;
          //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
          //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
		}
	}
	if(CURR_LEVEL==-8)
	{
		if(NEGEIGSW) removeAllRoids(asteroids);
		NEGEIGSW = false;
		numRoids=15;
		while(roids.length<numRoids)
			{
				var i = Math.floor(Math.random() * (3 - 0 + 1) + 0);
				//POINTS = i
				//READOUT.innerHTML = getReadout();
				if(i==0) i=23;
				else if(i==1) i=22;
				else i=21;
				var proto = protos[i];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = left+ (Math.random() * (right-left))
				if(i == 25) roid.position.y = -250;
				else roid.position.y = 450;
				roid.material = Object.create(roid.material);
			  //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			  //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
				
				roids.push(roid);
			}
	}
	if(CURR_LEVEL==-7)
	{
		if(NEGSEVSW) removeAllRoids(asteroids);
		NEGSEVSW = false;
		numRoids=15
		while(roids.length<numRoids)
			{
				var i = Math.floor(Math.random() * (26 - 20 + 1) + 20);
				//POINTS = i
				//READOUT.innerHTML = getReadout();
				var proto = protos[i];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = left+ (Math.random() * (right-left))
				if(i == 25) roid.position.y = -250;
				else roid.position.y = 450;
				roid.material = Object.create(roid.material);
			  //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			  //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
				
				roids.push(roid);
			}
	}
	if(CURR_LEVEL==-6)
	{
		if(NEGSIXSW) removeAllRoids(asteroids);
		NEGSIXSW = false;
		numRoids=15
		while(roids.length<numRoids)
		{
			
			/*var proto = protos[20];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 300;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);*/
			var random = Math.floor(Math.random() * (2));
			if(random== 0) random = 24;
			else if(random==1) random = 25;
			var proto = protos[random];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			if(random == 25) roid.position.y = -250;
			else roid.position.y = 450;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}
	if(CURR_LEVEL==-5)
	{
		if(NEGFIVESW) removeAllRoids(asteroids);
		NEGFIVESW = false;
		numRoids = 4;
		while(roids.length<numRoids)
		{
			var proto = protos[23];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 450;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}
	if(CURR_LEVEL==-4)
	{
		numRoids = 15;
		READOUT.innerHTML = getReadout();
		while(roids.length<numRoids)
		{
			var random = Math.floor(Math.random() * (2));
			if(random== 0) random = 21;
			else if(random==1) random = 22;
			var proto = protos[random];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 450;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}
	if(CURR_LEVEL==-3)
	{
		numRoids = 13;
		READOUT.innerHTML = getReadout();
		while(roids.length<numRoids)
		{
			var proto = protos[21];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 450;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}
	if(CURR_LEVEL==-2)
	{
		if(START)
		{
			TITLE_AUDIO.pause();
			DARK_THEME.play();
			START = false;
		}
		numRoids = 5;
		READOUT.innerHTML = getReadout();
		while(roids.length<numRoids)
		{
			var proto = protos[20];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 300;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
		
	}
	if(CURR_LEVEL==-1)
	{
		numRoids = 1;
		
		
		while(roids.length<numRoids)
		{
			var proto = protos[roidNumber];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = right;
			roid.position.y = 0;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
			if(roids.length==1) roidNumber++;
			if(roidNumber>19)
			{
				roidNumber = 10;
			}
		}
	}
	
	if(POINTS==-1)
	{
		//draw special pacman
		var proto = protos[19];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = right-258;
		roid.position.y = 120;
		roid.userData["velocity"] = [0,0,0];
		roid.userData["Points"] = -1;
		roid.material = Object.create(roid.material);
		
		roids.push(roid);
	}
	
	if(CURR_LEVEL==0 && DRAW)
	{
		var banProto = banProtos[3];
		banProto.visible = false;
		var ban = banProto.clone();
		ban.visible = true;
		ban.position.x = 0;
		ban.position.y = 200;
		ban.material = Object.create(ban.material);
		
		bans.push(ban);
		
		var banProto = banProtos[0];
		banProto.visible = false;
		var ban = banProto.clone();
		ban.visible = true;
		ban.position.x = left+100;
		ban.position.y = -100;
		ban.material = Object.create(ban.material);
		
		bans.push(ban);
		
		var proto = protos[0];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = left+100;
		roid.position.y = -150;
		roid.userData["velocity"] = [0,0,0];
		roid.userData["Points"] = 1;
		roid.material = Object.create(roid.material);
		
		roids.push(roid);
		
		var banProto = banProtos[1];
		banProto.visible = false;
		var ban = banProto.clone();
		ban.visible = true;
		ban.position.x = 0;
		ban.position.y = -100;
		ban.material = Object.create(ban.material);
		
		bans.push(ban);
		
		var proto = protos[1];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = 0;
		roid.position.y = -150;
		roid.userData["velocity"] = [0,0,0];
		roid.userData["Points"] = 2;
		roid.material = Object.create(roid.material);
		
		roids.push(roid);
		
		var banProto = banProtos[2];
		banProto.visible = false;
		var ban = banProto.clone();
		ban.visible = true;
		ban.position.x = right-100;
		ban.position.y = -100;
		ban.material = Object.create(ban.material);
		
		bans.push(ban);
		
		var proto = protos[2];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = right-100;
		roid.position.y = -150;
		roid.userData["velocity"] = [0,0,0];
		roid.userData["Points"] = 3;
		roid.material = Object.create(roid.material);
		
		roids.push(roid);
		
		var proto = protos[9];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = right-258;
		roid.position.y = 120;
		roid.userData["velocity"] = [0,0,0];
		roid.userData["Points"] = -1;
		roid.material = Object.create(roid.material);
		
		roids.push(roid);
		/*
		var proto = protos[10];
		proto.visible = false;
		var roid = proto.clone();
		roid.visible = true;
		roid.position.x = right;
		roid.position.y = 0;
		//roid.userData["velocity"] = [0,0,0];
		roid.material = Object.create(roid.material);*/
		
		//roids.push(roid);
		DRAW = false;
	}
	if(CURR_LEVEL==1)
	{
		while(roids.length<numRoids)
		{
			var proto = protos[0];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+ (Math.random() * (right-left))
			roid.position.y = 450;
			roid.material = Object.create(roid.material);
			//roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			//if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
			
			roids.push(roid);
		}
	}
    if(CURR_LEVEL==2)
    {
        numRoids = 5;
        while(roids.length<numRoids)
        {
            var proto = protos[1];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
            //roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
            //if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
    }
    if(CURR_LEVEL==3)
    {
        numRoids = 8;
        while(roids.length<numRoids)
        {
            var proto = protos[2];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
           // roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
           // if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
    }
    if(CURR_LEVEL==4)
    {
        numRoids = 2;
        while(roids.length<numRoids)
        {
            var proto = protos[3];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = Math.random() * (right-left) + left;
            roid.position.y = Math.random() * 380;
            roid.material = Object.create(roid.material);
          //  roid.userData["velocity"][0] = (Math.random() -0.5) * ROID_SPEED;
          //  roid.userData["velocity"][1] = 0;
           // if(roid.userData["velocity"][0]<75) roid.userData["velocity"][0] = 75;
            // move in x direction.
            
            roids.push(roid);
        }
    }
    if(CURR_LEVEL==5)
    {
        numRoids = 12;
        while(roids.length<numRoids)
        {
			var random = Math.floor(Math.random() * (4))
			if(random == 3) random = 4;
            var proto = protos[random];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
           // roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
           // if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
    }
    if(CURR_LEVEL==6)
    {
        numRoids = 12;
        while(roids.length<numRoids)
        {
            var proto = protos[4];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
          //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
           // if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
        
    }
	if(CURR_LEVEL==7)
    {
        numRoids = 12;
        while(roids.length<numRoids)
        {
            var proto = protos[5];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
          //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
          //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
        
    }
	if(CURR_LEVEL==8)
    {
        numRoids = 12;
        while(roids.length<numRoids)
        {
			var random = Math.floor(Math.random() * (2));
			if(random== 0) random = 4;
			else if(random==1) random = 6;
            var proto = protos[random];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
         //   roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
          //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
        
    }
	if(CURR_LEVEL==9)
    {
        numRoids = 12;
        while(roids.length<numRoids)
        {
            var proto = protos[7];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+ (Math.random() * (right-left))
            roid.position.y = 350;
            roid.material = Object.create(roid.material);
          //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
          //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
        }
        
    }
	if(CURR_LEVEL==10)
    {
        // boss level.
		numRoids = 15;
		if(roids.length==0&&FIRST) // spawn cherry before if block, then do is roids.length is zero
		// to spawn giant pac dot and animated pac man, start sounds, start fight. set SPACE_BAR = to a different key
		// to disable shooting during animation.
		{
			var proto = protos[0];
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = left+(right) //(Math.random() * (right-left))
            roid.position.y = 450;
            roid.material = Object.create(roid.material);
          //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
          //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
            
            roids.push(roid);
			FIRST=false;
			BOSSSPAWN = true;
		}
		else if(roids.length==0&&BOSSSPAWN)
		{
			//spawn PACMAN
			//infinitely spawn other asteroids
			MAIN_AUDIO.pause();
			BOSS_AUDIO.play();
			var proto = protos[8];
			proto.visible = false;
			var roid = proto.clone();
			roid.visible = true;
			roid.position.x = left+right
			roid.position.y = 350;
			roid.material = Object.create(roid.material);
			
			roids.push(roid);
			BOSSSPAWN= false;
			
		}
		else if(roids.length<numRoids&&!FIRST&&!BOSSSPAWN)
		{
			//Math.random() * (max - min) + min;
			
			while(roids.length<numRoids)
			{
				var i = Math.floor(Math.random() * (7 - 0 + 1) + 0);
				//POINTS = i
				//READOUT.innerHTML = getReadout();
				var proto = protos[i];
				proto.visible = false;
				var roid = proto.clone();
				roid.visible = true;
				roid.position.x = left+ (Math.random() * (right-left))
				roid.position.y = 350;
				roid.material = Object.create(roid.material);
			  //  roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
			  //  if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = -75;
				
				roids.push(roid);
			}
		}
        
    }
	if(CURR_LEVEL==11)
	{
		//remove asteroids and reset ship position.
		// fly off into sunset
		
		numRoids = 0;
		while(roids.length>numRoids)
		{
			roids.pop();
		}
		
	}
    /*if(CURR_LEVEL==5)
    {
        numRoids = 12
        var proto = protos[3];
        proto.visible = false;
        var roid = proto.clone();
        roid.visible = true;
        roid.position.x = Math.random() * (right-left) + left;
        roid.position.y = Math.random() * 380;
        roid.material = Object.create(roid.material);
        roid.userData["velocity"][0] = (Math.random() -0.5) * ROID_SPEED;
        roid.userData["velocity"][1] = 0;
        if(roid.userData["velocity"][0]<75) roid.userData["velocity"][0] = 75;
        
        while(roids.length<numRoids)
        {
            var proto = protos[4];
            if(proto===undefined)
            {
                debug("udefined");
                break;
            }
            proto.visible = false;
            var roid = proto.clone();
            roid.visible = true;
            roid.position.x = Math.random() * (right-left) + left;
            roid.position.y = Math.random() * 380;
            roid.material = Object.create(roid.material);
            roid.userData["velocity"][1] = (Math.random() -0.5) * ROID_SPEED;
            roid.userData["velocity"][0] = 0;
            if(roid.userData["velocity"][1]<75) roid.userData["velocity"][1] = 75;
        }
    }*/
	

    //READOUT.innerHTML = getReadout();
}

function updateAsteroids(asteroids, left, right, ship, asteroidShotNode, prototypes)
{
	// update position and rotation, based on velocity
	var protos = prototypes.children;
	var roids = asteroids.children;
	for (var i=0; i<roids.length; i++) {
		var roid = roids[i];
		/*if(roid.userData["waitTime"]==1)
		{
			debug(roid.userData["waitTime"]);
			if(roid.userData["waitTime"]<0)
			{
				// shoot key down
				roid.userData["velocity"][1] = -100;
				var velocity = roid.userData["velocity"];
				roid.position.x += velocity[0] * frameDuration;
				roid.position.y += velocity[1] * frameDuration;
				if(roid.position.x>=right) roid.position.x = left + 10;
				if(roid.position.y<=left) roid.position.x = right - 10;
				if(roid.position.y<-450) 
				{
					roid.position.y = 450;
					roid.userData["waitTime"] = 4;
				}
			}
			else
			{
				debug(frameDuration);
				//var current = roid.userData["waitTime"];
				//var newTime = current - frameDuration;
				var framer = frameDuration*50;
				debug(framer);
				var prevTime = roid.userData["waitTime"];
				roid.userData["waitTime"] = prevTime - framer;
				debug("waitime is : " + roid.userData["waitTime"]);
			}
		}*/
		
		//else
		//{
			var velocity = roid.userData["velocity"];
			roid.position.x += velocity[0] * frameDuration;
			roid.position.y += velocity[1] * frameDuration;
			//NAMEOFROID = roid.name
			if(roid.name=="PacMan"&&roid.position.x>=right)
			{
				roid.position.y -= 130;
				roid.position.x = left + 10;
			}
			if(roid.position.x>=right) roid.position.x = left + 10;
			if(roid.position.x<=left) roid.position.x = right - 10;
			if(roid.position.y<-450) 
			{
				if(roid.name=="PacMan") roid.position.y = 350;
				else roid.position.y = 450;
			}
			if((EasterBossAnimation1||EasterBossAnimation3||EasterRound2)&&roid.name=="DarkPacManBoss")
			{
				if(roid.position.x<=5 && roid.position.x>= -5)
				{
					roid.userData["velocity"][0] = 0;
					roid.userData["velocity"][1] = 0;
					roid.position.x = 0;
					
					if(preRound) 
					{
						EasterBossAnimation2 = true;
						preRound = false;
					}
					else if(EasterRound2)
					{
						TurnDark = true;
						//EasterBossAnimation3= false;
					}
					else if(EasterRound2&&false)
					{
						TurnDark = true;
					}
					/*else if(EasterSW) 
					{
						EasterBossAnimation3 = true;
						EasterSW = false;
						EasterSWDe = true;
					}*/
				}
			}
			if((EasterBossAnimation2||EasterBossAnimation3||EasterRound2)&&(roid.name=="red"||roid.name=="blue"||roid.name=="pink"||roid.name=="orangy"))
			{
				if(roid.position.x<=5 && roid.position.x>= -5)
				{
					roid.userData["velocity"][0] = 0;
					roid.userData["velocity"][1] = 0;
					roid.position.x = 0;
					COUNTER++;
					//currHP = COUNTER;
					//READOUT.innerHTML = getReadout();
					//roids[0].userData["rotation"] +=10;
					
					if(EasterBossAnimation2) EasterRound1 = true;
					else if(EasterRound2&&COUNTER==300&&DRAWDARK)
					{
							if(roids[1].name=="red")
							{
								roids.splice(1,1);
								var proto = protos[32];
								proto.visible = false;
								var roid = proto.clone();
								roid.visible = true;
								roid.position.x = 0;
								roid.position.y = 250;
								roid.material = Object.create(roid.material);
								roid.userData["velocity"][0] = 0;
								roid.userData["velocity"][1] = 0;
								roids.push(roid);
								COUNTER-=300;
							}
							else if(roids[1].name=="blue")
							{
								roids.splice(1,1);
								var proto = protos[33];
								proto.visible = false;
								var roid = proto.clone();
								roid.visible = true;
								roid.position.x = 0;
								roid.position.y = 200;
								roid.material = Object.create(roid.material);
								roid.userData["velocity"][0] = 0;
								roid.userData["velocity"][1] = 0;
								roids.push(roid);
								COUNTER-=300;
							}
							else if(roids[1].name=="pink")
							{
								roids.splice(1,1);
								var proto = protos[34];
								proto.visible = false;
								var roid = proto.clone();
								roid.visible = true;
								roid.position.x = 0;
								roid.position.y = 150;
								roid.material = Object.create(roid.material);
								roid.userData["velocity"][0] = 0;
								roid.userData["velocity"][1] = 0;
								roids.push(roid);
								COUNTER-=200;
							}
							else if(roids[1].name=="orangy")
							{
								roids.splice(1,1);
								var proto = protos[35];
								proto.visible = false;
								var roid = proto.clone();
								roid.visible = true;
								roid.position.x = 0;
								roid.position.y = 100;
								roid.material = Object.create(roid.material);
								roid.userData["velocity"][0] = 0;
								roid.userData["velocity"][1] = 0;
								roid.userData["HP"] = 10000;
								roids.push(roid);
								//COUNTER-=50;
								
								DRAWDARK=false;
								FinalBattle = true;
								EasterRound2=false;
								EasterBossAnimation3=false;
						}
					}
					//else if(EasterBossAnimation3) var x = 1;
				}
			}
	//}
        /*if(roid.userData["fires"]>0)
        {
            var shotsToFire = roid.userData["fires"];
            //fire shot from asteroid.
            updateAsteroidShot(roid, ship, shotsToFire, asteroidShotNode)
        }*/
		//toroidalBoundary(roid.position, left, right);
		//
		/*
		if (frameNum%120 == 0) {
			texture = material.map;
			var offset = texture.repeat.x * (frameNum/120);
			offset -= Math.floor(offset);
			texture.offset.x = offset;
		}*/
	}
}
var CURR_AstSHOT = 0;
function updateAsteroidShot(roid, ship, shotsToFire, asteroidShotNode)
{
    var shots = asteroidShotNode.children;
    //debug("shots to fire =   ");
    //debug(shotsToFire);
    while (shots.length < shotsToFire) {
        shots[0].visible = false;
        var shot = shots[0].clone();
        shot.userData["velocity"][1] = 5;
        shots.push(shot);
    }
    // Update the position of the shots
    for (var i=0; i<shots.length; i++) {
        var shot = shots[i];
        var velocity = shot.userData["velocity"];
        //shot.position.x += velocity[0] * frameDuration;
        shot.position.y -= velocity[1] *(frameDuration+0.2);
        //toroidalBoundary(shot.position, left, right);
        //shot.userData["time"] -= frameDuration;
        if (shot.position.y < -450)
        {
            shot.visible = false;
            shotsToFire++;
        }
    }
    if(roid.visible == true && shotsToFire>0 && shots[CURR_AstSHOT].visible == false)
    {
        shot = shots[CURR_AstSHOT]
        shot.visible = true;
        shot.position.x = roid.position.x;
        shot.position.y = roid.position.y;
        shot.userData["velocity"][1] = 5;
        shotsToFire--;
    }
}
